package com.kakdela.p2p

import android.app.Application

class App : Application()
